// In this tutorial I didn't factor out any of the widget tree into separate
// widgets, but it is a good idea, especially if you use the same widget
// in different parts of your app.
//
// If you do you can put your widgets in this folder.
//
// If a widget needs its own app state then it can have its own view model.